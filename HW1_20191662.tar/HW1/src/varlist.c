#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "varlist.h"

// TODO: Fill in
//리스트에 변수명과, 변수명에 대응하는 숫자 값 삽입
VarNode* make_varlist(char *var, int val, VarNode *next) {
   VarNode *newnode = (VarNode *)malloc(sizeof(VarNode));
   newnode->var=var;
   newnode->val=val;
   newnode->next=next;
   return newnode;
}

// TODO: Fill in
//변수명에 대응하는 숫자 값 return
int lookup_var(VarNode *head, char *var) {
    VarNode *current =head;
    while(current!=NULL){
        if(strcmp(current->var,var)==0)return current->val;
        current=current->next;
    }
    return -1;
}

// TODO: Fill in
void free_varlist(VarNode *head) {
    VarNode *current = head;
    while (current != NULL) {
        VarNode *temp = current;
        current = current->next;
        free(temp->var);  // Free the memory for the variable name
        free(temp);       // Free the memory for the node
    }
    return;
}
